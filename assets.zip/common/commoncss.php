      <!--favicon-->
	  <link rel="icon" type="image/x-icon" href="<?php echo $url; ?>assets/images/favicon.png"/>
      <!--css-->
      <link rel="stylesheet" href="<?php echo $url; ?>assets/css/common.css" type="text/css"/>
	  <link rel="stylesheet" href="<?php echo $url; ?>assets/css/header.css" type="text/css"/>
	  <link rel="stylesheet" href="<?php echo $url; ?>assets/css/fonts.css" type="text/css"/>
	  <link rel="stylesheet" href="<?php echo $url; ?>assets/css/style.css" type="text/css"/>
	  <link rel="stylesheet" href="<?php echo $url; ?>assets/css/footer.css" type="text/css"/>
	  <!--animate css-->
	  <link rel="stylesheet" href="<?php echo $url; ?>assets/css/animate.css" type="text/css"/>
      <!--font css-->
	  <link rel="stylesheet" href="<?php echo $url; ?>assets/css/font-awesome.min.css" type="text/css"/>
	  <link rel="stylesheet" href="<?php echo $url; ?>assets/css/feather.css" type="text/css"/>
     <!--owl carousel -->
      <link rel="stylesheet" href="<?php echo $url; ?>assets/css/owl.carousel.min.css" type="text/css"/>
     <link rel="stylesheet" href="<?php echo $url; ?>assets/css/owl.theme.default.min.css" type="text/css"/>
     
      