<div class="col-md-4">
   <div class="recentPosts">
      <h2>Recent Posts</h2>
      <ul>
          <li>
            <a class="blogImage" href="/blogs/reasons-why-customer-centricity-is-important-for-every-businesses"><img src="../assets/images/reasons-why-customer-centricity-is-important-for-every-businesses.jpg" title="Custom Software Development " alt="image"/></a>
            <div class="blogContent">
               <div class="blogInnerContent"><a class="active" href="/blogs/reasons-why-customer-centricity-is-important-for-every-businesses" target="_self">Reasons Why Customer Centricity Is Important For Every Businesses</a></div>
               <div class="srpw-meta">15 June , 2021</div>
            </div>
         </li>
         <li>
            <a class="blogImage" href="/blogs/benefits-of-hiring-a-remote-software-development-company-for-your-project"><img src="../assets/images/benefits-of hiring-a-remote-software-development-company-for-your-project.jpg" title="Custom Software Development " alt="image"/></a>
            <div class="blogContent">
               <div class="blogInnerContent"><a class="active" href="/blogs/benefits-of-hiring-a-remote-software-development-company-for-your-project" target="_self">7 Benefits Of Hiring A Remote Software Development Company For Your Project</a></div>
               <div class="srpw-meta">31 May , 2021</div>
            </div>
         </li>
		  <li>
            <a class="blogImage" href="/blogs/why-to-outsource-your-project-to-a-custom-software-development-company"><img src="../assets/images/why-to-outsource-your-project-to-a-custom-software-development-company.jpg" title="Custom Software Development " alt="image"/></a>
            <div class="blogContent">
               <div class="blogInnerContent"><a class="active" href="/blogs/why-to-outsource-your-project-to-a-custom-software-development-company" target="_self">Why To Outsource Your Project To A Custom Software Development Company?...</a></div>
               <div class="srpw-meta">19 May , 2021</div>
            </div>
         </li>
		  <li>
            <a class="blogImage" href="/blogs/greentech-platform-vs-technology"><img src="../assets/images/greentech-platform-vs-technology.jpg" title="Custom Software Development" alt="image"/></a>
            <div class="blogContent">
               <div class="blogInnerContent"><a class="active" href="/blogs/greentech-platform-vs-technology" target="_self">Greentech Platform Vs Technology</a></div>
               <div class="srpw-meta">18 March , 2021</div>
            </div>
         </li>
		   <li>
            <a class="blogImage" href="/blogs/affiliate-marketing-green-tech-platform-and-the-world"><img src="../assets/images/affiliate-marketing-green-tech-platform-and-the-world.jpg" alt="image" title=" Green Tech Platform "/></a>
            <div class="blogContent">
               <div class="blogInnerContent"><a class="active" href="/blogs/affiliate-marketing-green-tech-platform-and-the-world" target="_self">Affiliate Marketing Green Tech Platform And The World</a></div>
               <div class="srpw-meta">16 March , 2021</div>
            </div>
         </li>
		   <li>
            <a class="blogImage" href="/blogs/evolutions-in-green-tech-platform"><img src="../assets/images/evolutions-in-green-tech-platform.jpg" alt="image" title="Green Tech Platform"/></a>
            <div class="blogContent">
               <div class="blogInnerContent"><a class="active" href="/blogs/evolutions-in-green-tech-platform" target="_self">Evolution In Green Tech Platform</a></div>
               <div class="srpw-meta">13 March , 2021</div>
            </div>
         </li>
		   <li>
            <a class="blogImage" href="/blogs/top-13-emerging-technology-trends-to-watch-in-2021"><img src="../assets/images/Blog-cover Dits-24.jpg" alt="image" title="Emerging Technology Trends"/></a>
            <div class="blogContent">
               <div class="blogInnerContent"><a class="active" href="/blogs/top-13-emerging-technology-trends-to-watch-in-2021" target="_self">Top #13 Emerging Technology Trends To Watch In 2021</a></div>
               <div class="srpw-meta">11 March , 2021</div>
            </div>
         </li>
		  <li>
            <a class="blogImage" href="/blogs/4-reasons-why-offshore-development-is-a-better-option-than-the-onshore"><img src="../assets/images/4-reasons-why-offshore-development.jpg" alt="image" title="Offshore Development"/></a>
            <div class="blogContent">
               <div class="blogInnerContent"><a class="active" href="/blogs/4-reasons-why-offshore-development-is-a-better-option-than-the-onshore" target="_self">4 Reasons Why Offshore Development Is A Better Option Than The Onshore</a></div>
               <div class="srpw-meta">08 March , 2021</div>
            </div>
         </li>
		  <li>
            <a class="blogImage" href="/blogs/the-new-era-of-custom-application-development-services-2021-and-beyond"><img src="../assets/images/era-of-custom.jpg" title="Custom Application Development" alt="image"/></a>
            <div class="blogContent">
               <div class="blogInnerContent"><a class="active" href="/blogs/the-new-era-of-custom-application-development-services-2021-and-beyond" target="_self">The New Era Of Custom Application Development Services–2021 And Beyond</a></div>
               <div class="srpw-meta">12 Feb , 2021</div>
            </div>
         </li>
         <li>
            <a class="blogImage" href="/blogs/10-benefits-of-hiring-full-stack-developers-for-your-projects"><img src="../assets/images/benefits-of-hiring.jpg" title="Hiring Full Stack Developers" alt="Hiring Full Stack Developers"/></a>
            <div class="blogContent">
               <div class="blogInnerContent"><a class="active" href="/blogs/10-benefits-of-hiring-full-stack-developers-for-your-projects" target="_self">10 Benefits Of Hiring Full Stack Developers For Your Projects...</a></div>
               <div class="srpw-meta">09 February , 2021</div>
            </div>
         </li>
         <li>
            <a class="blogImage" href="/blogs/Why-CRM-is-Important-in-the-Current-Situation"><img src="../assets/images/blogimage3.jpg" title="CRM" alt="CRM"/></a>
            <div class="blogContent">
               <div class="blogInnerContent"><a class="active" href="/blogs/Why-CRM-is-Important-in-the-Current-Situation" target="_self">Why CRM Is Important In The Current Situation...</a></div>
               <div class="srpw-meta">24 July , 2020</div>
            </div>
         </li>
         <li>
            <a class="blogImage" href="/blogs/business-process-management"><img src="../assets/images/blogimage1.jpg" title="Business Process Management" alt="Business Process Management"/></a>
            <div class="blogContent">
               <div class="blogInnerContent"><a class="active" href="/blogs/business-process-management" target="_self">Customized Business Process Management And Workflow...</a></div>
               <div class="srpw-meta">16 April , 2020</div>
            </div>
         </li>
      </ul>
   </div>
</div>