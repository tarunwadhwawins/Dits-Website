       <script>
       		var base_url = "<?php echo $url; ?>";
       </script>
       <script src="<?php echo $url; ?>assets/js/jquery.min.js"></script>
	   <script src="<?php echo $url; ?>assets/js/popper.min.js"></script>
	   <script src="<?php echo $url; ?>assets/js/bootstrap.min.js"></script>
	   <script src="<?php echo $url; ?>assets/js/jquery.counterup.min.js"></script>
	   <script src="<?php echo $url; ?>assets/js/wow.min.js"></script>
       <script src="<?php echo $url; ?>assets/js/owl.carousel.js"></script>
       <script src="<?php echo $url; ?>assets/js/jquery.nicescroll.min.js"></script>
       <script src="<?php echo $url; ?>assets/js/custom.js"></script>
	   <script src="<?php echo $url; ?>assets/js/jquery.validate.js"></script>
	   <script src="<?php echo $url; ?>assets/js/contact.js"></script>
	   <script src="<?php echo $url; ?>assets/js/quotes.js"></script>
    <script src="<?php echo $url; ?>assets/js/modelCountry.js"></script>
    <script src="<?php echo $url; ?>assets/js/imageMapResizer.min.js"></script>
    
        <script src="<?php echo $url; ?>assets/js/countrystatecity.js"></script>
	  <script type="text/javascript">

		//$('map').imageMapResize();

	</script>
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ce4ebf2d07d7e0c6394c71b/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();

</script>